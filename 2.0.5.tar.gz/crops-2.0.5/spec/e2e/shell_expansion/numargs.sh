#!/bin/bash
echo "$#"
